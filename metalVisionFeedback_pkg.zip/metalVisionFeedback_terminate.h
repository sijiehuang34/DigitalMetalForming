//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// metalVisionFeedback_terminate.h
//
// Code generation for function 'metalVisionFeedback_terminate'
//

#ifndef METALVISIONFEEDBACK_TERMINATE_H
#define METALVISIONFEEDBACK_TERMINATE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void metalVisionFeedback_terminate();

#endif
// End of code generation (metalVisionFeedback_terminate.h)
