//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// metalVisionFeedback_data.h
//
// Code generation for function 'metalVisionFeedback_data'
//

#ifndef METALVISIONFEEDBACK_DATA_H
#define METALVISIONFEEDBACK_DATA_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern boolean_T isInitialized_metalVisionFeedback;

#endif
// End of code generation (metalVisionFeedback_data.h)
