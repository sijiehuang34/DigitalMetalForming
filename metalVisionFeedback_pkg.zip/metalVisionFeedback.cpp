//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// metalVisionFeedback.cpp
//
// Code generation for function 'metalVisionFeedback'
//

// Include files
#include "metalVisionFeedback.h"
#include "metalVisionFeedback_data.h"
#include "metalVisionFeedback_initialize.h"
#include "metalVisionFeedback_internal_types.h"
#include "metalVisionFeedback_types.h"
#include "regionprops.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "rt_nonfinite.h"
#include <cstddef>
#include <math.h>
#include <stdio.h>

// Function Declarations
static double rt_roundd_snf(double u);

// Function Definitions
static double rt_roundd_snf(double u)
{
  double y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }
  return y;
}

void metalVisionFeedback(const boolean_T[388800], const cell_0 *,
                         const double L[388800])
{
  coder::array<struct_T, 1U> stats;
  coder::array<double, 2U> result;
  coder::array<char, 2U> str;
  int i;
  if (!isInitialized_metalVisionFeedback) {
    metalVisionFeedback_initialize();
  }
  //  Input bw: the binarized image,
  //  Input B: the boundary coordinates for every bounded shape
  //  Input L: the label matrix of each shape
  //  No output (final image will be displayed on a fig window automatically)
  //  Display each shape in a different color
  //  0.5 sets the background gray
  //  DEBUG NOTES: 2nd argument 'colormap'; must use standard syntax nx3 double
  //  Number of unique labels in L (THIS ENSURES EVERY LABEL GETS A UNIQUE
  //  COLOR) Generate a jet colormap with n colors Make the boundaries white for
  //  visualization for i-many shapes the boundary coordinates for the i-th
  //  shape plot coord. in white for i-many shapes the boundary coordinates for
  //  the i-th shape plot coord. in white for i-many shapes the boundary
  //  coordinates for the i-th shape plot coord. in white Obtain shape
  //  properties
  coder::regionprops(L, stats);
  //  Single out the punch, store & display properties
  i = stats.size(0);
  for (int b_i = 0; b_i < i; b_i++) {
    double d;
    double ex;
    int i1;
    int idx;
    int k;
    int last;
    boolean_T exitg1;
    //  Area (pxl)
    //  DEBUG NOTES: Must use standard syntax to ensure output is scalar
    i1 = stats.size(0);
    if (stats.size(0) == 0) {
      last = 0;
    } else {
      last = stats.size(0);
    }
    result.set_size(1, last);
    for (idx = 0; idx < i1; idx++) {
      result[idx] = stats[idx].Area;
    }
    last = result.size(1);
    if (result.size(1) <= 2) {
      if (result.size(1) == 1) {
        ex = result[0];
      } else if ((result[0] < result[result.size(1) - 1]) ||
                 (rtIsNaN(result[0]) &&
                  (!rtIsNaN(result[result.size(1) - 1])))) {
        ex = result[result.size(1) - 1];
      } else {
        ex = result[0];
      }
    } else {
      if (!rtIsNaN(result[0])) {
        idx = 1;
      } else {
        idx = 0;
        k = 2;
        exitg1 = false;
        while ((!exitg1) && (k <= last)) {
          if (!rtIsNaN(result[k - 1])) {
            idx = k;
            exitg1 = true;
          } else {
            k++;
          }
        }
      }
      if (idx == 0) {
        ex = result[0];
      } else {
        ex = result[idx - 1];
        i1 = idx + 1;
        for (k = i1; k <= last; k++) {
          d = result[k - 1];
          if (ex < d) {
            ex = d;
          }
        }
      }
    }
    if (stats[b_i].Area != ex) {
      i1 = stats.size(0);
      if (stats.size(0) == 0) {
        last = 0;
      } else {
        last = stats.size(0);
      }
      result.set_size(1, last);
      for (idx = 0; idx < i1; idx++) {
        result[idx] = stats[idx].Area;
      }
      last = result.size(1);
      if (result.size(1) <= 2) {
        if (result.size(1) == 1) {
          ex = result[0];
        } else if ((result[0] > result[result.size(1) - 1]) ||
                   (rtIsNaN(result[0]) &&
                    (!rtIsNaN(result[result.size(1) - 1])))) {
          ex = result[result.size(1) - 1];
        } else {
          ex = result[0];
        }
      } else {
        if (!rtIsNaN(result[0])) {
          idx = 1;
        } else {
          idx = 0;
          k = 2;
          exitg1 = false;
          while ((!exitg1) && (k <= last)) {
            if (!rtIsNaN(result[k - 1])) {
              idx = k;
              exitg1 = true;
            } else {
              k++;
            }
          }
        }
        if (idx == 0) {
          ex = result[0];
        } else {
          ex = result[idx - 1];
          i1 = idx + 1;
          for (k = i1; k <= last; k++) {
            d = result[k - 1];
            if (ex > d) {
              ex = d;
            }
          }
        }
      }
      if (stats[b_i].Area != ex) {
        //  should work even when punch isn't visible
        //  Extremas
        //  get the extrema for the i-th region
        //  plot the extrema points in red
        //  Outline the leftmost edge
        //  left-bottom x
        //  left-top x
        //  left-bottom y
        //  left-top y
        //  Calculate the angle deviation
        //  Positive angle: tilted towards the right (anticlockwise)
        //  Negative angle: tilted towards the left (clockwise)
        //  DEBUG NOTES: Only supports round(x) syntax
        ex = rt_roundd_snf(
            57.295779513082323 *
            atan((stats[b_i].Extrema[6] - stats[b_i].Extrema[7]) /
                 (stats[b_i].Extrema[14] - stats[b_i].Extrema[15])));
        if ((!(ex == 0.0)) && (!rtIsInf(ex))) {
          char st[24];
          sprintf(&st[0], "%.16g", ex);
        }
        //  Centroid
        idx = (int)snprintf(NULL, 0, "Centroid (Punch): (%.4f, %.4f)",
                            stats[b_i].Centroid[0], stats[b_i].Centroid[1]) +
              1;
        str.set_size(1, idx);
        snprintf(&str[0], (size_t)idx, "Centroid (Punch): (%.4f, %.4f)",
                 stats[b_i].Centroid[0], stats[b_i].Centroid[1]);
      }
    }
  }
  //  Match & append the boundary data to the stats structure
  //  DEBUG NOTES: Cannot directly access a field
  //  [stats.Boundary] = deal([]);
  //  Find midpoints of the bending part
  //  Initialize a logical array to track columns with midpoints
  //  DEBUG NOTES: Do not have an array with undetermined size
  //  Preallocate the matrix with the maximum possible size
  //  Variable to keep track of the number of midpoints found
  //  Remove unused preallocated rows
  //  Draw the midpoints
}

// End of code generation (metalVisionFeedback.cpp)
