//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// metalVisionFeedback_initialize.h
//
// Code generation for function 'metalVisionFeedback_initialize'
//

#ifndef METALVISIONFEEDBACK_INITIALIZE_H
#define METALVISIONFEEDBACK_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void metalVisionFeedback_initialize();

#endif
// End of code generation (metalVisionFeedback_initialize.h)
