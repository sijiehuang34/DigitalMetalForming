//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// metalVisionFeedback_types.h
//
// Code generation for function 'metalVisionFeedback'
//

#ifndef METALVISIONFEEDBACK_TYPES_H
#define METALVISIONFEEDBACK_TYPES_H

// Include files
#include "rtwtypes.h"

// Type Definitions
struct cell_0 {
  double f1[2010];
  double f2[1448];
  double f3[2548];
};

#endif
// End of code generation (metalVisionFeedback_types.h)
