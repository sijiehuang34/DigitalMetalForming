//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// regionprops.cpp
//
// Code generation for function 'regionprops'
//

// Include files
#include "regionprops.h"
#include "metalVisionFeedback_internal_types.h"
#include "minOrMax.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "rt_nonfinite.h"
#include <math.h>
#include <string.h>

// Type Definitions
struct b_struct_T {
  double Area;
  double Centroid[2];
  double BoundingBox[4];
  double MajorAxisLength;
  double MinorAxisLength;
  double Eccentricity;
  double Orientation;
  coder::array<boolean_T, 2U> Image;
  coder::array<boolean_T, 2U> FilledImage;
  double FilledArea;
  double EulerNumber;
  double Extrema[16];
  double EquivDiameter;
  double Extent;
  coder::array<double, 1U> PixelIdxList;
  coder::array<double, 2U> PixelList;
  double Perimeter;
  double Circularity;
  coder::array<double, 1U> PixelValues;
  double WeightedCentroid[2];
  double MeanIntensity;
  double MinIntensity;
  double MaxIntensity;
  coder::array<double, 2U> SubarrayIdx;
  double SubarrayIdxLengths[2];
};

struct c_struct_T {
  boolean_T Area;
  boolean_T Centroid;
  boolean_T Extrema;
  boolean_T PixelIdxList;
  boolean_T PixelList;
};

// Function Declarations
namespace coder {
static void ComputePixelIdxList(const double L[388800], double numObjs,
                                ::coder::array<b_struct_T, 1U> &stats,
                                c_struct_T *statsAlreadyComputed);

static void ComputePixelList(::coder::array<b_struct_T, 1U> &stats,
                             c_struct_T *statsAlreadyComputed);

} // namespace coder

// Function Definitions
namespace coder {
static void ComputePixelIdxList(const double L[388800], double numObjs,
                                ::coder::array<b_struct_T, 1U> &stats,
                                c_struct_T *statsAlreadyComputed)
{
  array<double, 1U> regionIndices;
  array<double, 1U> regionLengths;
  array<int, 1U> idxCount;
  array<int, 1U> idxCount_tmp;
  if (!statsAlreadyComputed->PixelIdxList) {
    statsAlreadyComputed->PixelIdxList = true;
    if (numObjs != 0.0) {
      double y;
      int firstBlockLength;
      int hi;
      int lastBlockLength;
      int nblocks;
      firstBlockLength = static_cast<int>(numObjs);
      regionLengths.set_size(firstBlockLength);
      for (lastBlockLength = 0; lastBlockLength < firstBlockLength;
           lastBlockLength++) {
        regionLengths[lastBlockLength] = 0.0;
      }
      for (nblocks = 0; nblocks < 720; nblocks++) {
        for (firstBlockLength = 0; firstBlockLength < 540; firstBlockLength++) {
          y = L[firstBlockLength + 540 * nblocks];
          if (static_cast<int>(y) > 0) {
            regionLengths[static_cast<int>(y) - 1] =
                regionLengths[static_cast<int>(y) - 1] + 1.0;
          }
        }
      }
      if (regionLengths.size(0) <= 1024) {
        firstBlockLength = regionLengths.size(0);
        lastBlockLength = 0;
        nblocks = 1;
      } else {
        firstBlockLength = 1024;
        nblocks = static_cast<int>(
            static_cast<unsigned int>(regionLengths.size(0)) >> 10);
        lastBlockLength = regionLengths.size(0) - (nblocks << 10);
        if (lastBlockLength > 0) {
          nblocks++;
        } else {
          lastBlockLength = 1024;
        }
      }
      y = regionLengths[0];
      for (int k = 2; k <= firstBlockLength; k++) {
        y += regionLengths[k - 1];
      }
      for (int ib = 2; ib <= nblocks; ib++) {
        double bsum;
        firstBlockLength = (ib - 1) << 10;
        bsum = regionLengths[firstBlockLength];
        if (ib == nblocks) {
          hi = lastBlockLength;
        } else {
          hi = 1024;
        }
        for (int k = 2; k <= hi; k++) {
          bsum += regionLengths[(firstBlockLength + k) - 1];
        }
        y += bsum;
      }
      regionIndices.set_size(static_cast<int>(y));
      if (regionLengths.size(0) != 1) {
        lastBlockLength = regionLengths.size(0);
        for (int k = 0; k <= lastBlockLength - 2; k++) {
          regionLengths[k + 1] = regionLengths[k] + regionLengths[k + 1];
        }
      }
      idxCount_tmp.set_size(regionLengths.size(0) + 1);
      idxCount_tmp[0] = 0;
      firstBlockLength = regionLengths.size(0);
      for (lastBlockLength = 0; lastBlockLength < firstBlockLength;
           lastBlockLength++) {
        idxCount_tmp[lastBlockLength + 1] =
            static_cast<int>(regionLengths[lastBlockLength]);
      }
      idxCount.set_size(idxCount_tmp.size(0));
      firstBlockLength = idxCount_tmp.size(0);
      for (lastBlockLength = 0; lastBlockLength < firstBlockLength;
           lastBlockLength++) {
        idxCount[lastBlockLength] = idxCount_tmp[lastBlockLength];
      }
      nblocks = 1;
      for (firstBlockLength = 0; firstBlockLength < 720; firstBlockLength++) {
        for (hi = 0; hi < 540; hi++) {
          y = L[hi + 540 * firstBlockLength];
          if (static_cast<int>(y) > 0) {
            idxCount[static_cast<int>(y) - 1] =
                idxCount[static_cast<int>(y) - 1] + 1;
            regionIndices[idxCount[static_cast<int>(y) - 1] - 1] = nblocks;
          }
          nblocks++;
        }
      }
      lastBlockLength = stats.size(0);
      for (int k = 0; k < lastBlockLength; k++) {
        nblocks = idxCount_tmp[k + 1];
        if (idxCount_tmp[k] + 1 > nblocks) {
          hi = 0;
          nblocks = 0;
        } else {
          hi = idxCount_tmp[k];
        }
        firstBlockLength = nblocks - hi;
        stats[k].PixelIdxList.set_size(firstBlockLength);
        for (nblocks = 0; nblocks < firstBlockLength; nblocks++) {
          stats[k].PixelIdxList[nblocks] = regionIndices[hi + nblocks];
        }
      }
    }
  }
}

static void ComputePixelList(::coder::array<b_struct_T, 1U> &stats,
                             c_struct_T *statsAlreadyComputed)
{
  array<int, 1U> v1;
  array<int, 1U> vk;
  if (!statsAlreadyComputed->PixelList) {
    int i;
    statsAlreadyComputed->PixelList = true;
    i = stats.size(0);
    for (int k = 0; k < i; k++) {
      int loop_ub;
      loop_ub = stats[k].PixelIdxList.size(0);
      if (loop_ub != 0) {
        v1.set_size(loop_ub);
        for (int i1 = 0; i1 < loop_ub; i1++) {
          v1[i1] = static_cast<int>(stats[k].PixelIdxList[i1]) - 1;
        }
        vk.set_size(v1.size(0));
        loop_ub = v1.size(0);
        for (int i1 = 0; i1 < loop_ub; i1++) {
          vk[i1] = v1[i1] / 540;
        }
        loop_ub = v1.size(0);
        for (int i1 = 0; i1 < loop_ub; i1++) {
          v1[i1] = v1[i1] - vk[i1] * 540;
        }
        stats[k].PixelList.set_size(vk.size(0), 2);
        loop_ub = vk.size(0);
        for (int i1 = 0; i1 < loop_ub; i1++) {
          stats[k].PixelList[i1] = vk[i1] + 1;
        }
        loop_ub = v1.size(0);
        for (int i1 = 0; i1 < loop_ub; i1++) {
          stats[k].PixelList[i1 + stats[k].PixelList.size(0)] = v1[i1] + 1;
        }
      } else {
        stats[k].PixelList.set_size(0, 2);
      }
    }
  }
}

void regionprops(const double varargin_1[388800],
                 ::coder::array<struct_T, 1U> &outstats)
{
  array<b_struct_T, 1U> stats;
  array<double, 1U> c;
  array<double, 1U> r;
  array<double, 1U> tmp;
  b_struct_T statsOneObj;
  c_struct_T statsAlreadyComputed;
  struct_T s;
  double d;
  double minR;
  double numObjs;
  int i;
  int idx;
  int k;
  int lastBlockLength;
  int nblocks;
  if (!rtIsNaN(varargin_1[0])) {
    idx = 1;
  } else {
    boolean_T exitg1;
    idx = 0;
    k = 2;
    exitg1 = false;
    while ((!exitg1) && (k <= 388800)) {
      if (!rtIsNaN(varargin_1[k - 1])) {
        idx = k;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }
  if (idx == 0) {
    minR = varargin_1[0];
  } else {
    minR = varargin_1[idx - 1];
    i = idx + 1;
    for (k = i; k < 388801; k++) {
      d = varargin_1[k - 1];
      if (minR < d) {
        minR = d;
      }
    }
  }
  minR = floor(minR);
  if ((minR <= 0.0) || rtIsNaN(minR)) {
    numObjs = 0.0;
  } else {
    numObjs = minR;
  }
  memset(&s.Extrema[0], 0, 16U * sizeof(double));
  s.Centroid[0] = 0.0;
  s.Centroid[1] = 0.0;
  s.Area = 0.0;
  outstats.set_size(static_cast<int>(numObjs));
  idx = static_cast<int>(numObjs);
  for (i = 0; i < idx; i++) {
    outstats[i] = s;
  }
  statsAlreadyComputed.Area = false;
  statsOneObj.Area = 0.0;
  statsAlreadyComputed.Centroid = false;
  statsOneObj.Centroid[0] = 0.0;
  statsOneObj.Centroid[1] = 0.0;
  statsOneObj.BoundingBox[0] = 0.0;
  statsOneObj.BoundingBox[1] = 0.0;
  statsOneObj.BoundingBox[2] = 0.0;
  statsOneObj.BoundingBox[3] = 0.0;
  statsOneObj.MajorAxisLength = 0.0;
  statsOneObj.MinorAxisLength = 0.0;
  statsOneObj.Eccentricity = 0.0;
  statsOneObj.Orientation = 0.0;
  statsOneObj.Image.set_size(0, 0);
  statsOneObj.FilledImage.set_size(0, 0);
  statsOneObj.FilledArea = 0.0;
  statsOneObj.EulerNumber = 0.0;
  statsAlreadyComputed.Extrema = false;
  memset(&statsOneObj.Extrema[0], 0, 16U * sizeof(double));
  statsOneObj.EquivDiameter = 0.0;
  statsOneObj.Extent = 0.0;
  statsAlreadyComputed.PixelIdxList = false;
  statsOneObj.PixelIdxList.set_size(0);
  statsAlreadyComputed.PixelList = false;
  statsOneObj.PixelList.set_size(0, 2);
  statsOneObj.Perimeter = 0.0;
  statsOneObj.Circularity = 0.0;
  statsOneObj.PixelValues.set_size(0);
  statsOneObj.MeanIntensity = 0.0;
  statsOneObj.MinIntensity = 0.0;
  statsOneObj.MaxIntensity = 0.0;
  statsOneObj.SubarrayIdx.set_size(1, 0);
  statsOneObj.WeightedCentroid[0] = 0.0;
  statsOneObj.SubarrayIdxLengths[0] = 0.0;
  statsOneObj.WeightedCentroid[1] = 0.0;
  statsOneObj.SubarrayIdxLengths[1] = 0.0;
  stats.set_size(static_cast<int>(numObjs));
  idx = static_cast<int>(numObjs);
  for (i = 0; i < idx; i++) {
    stats[i] = statsOneObj;
  }
  ComputePixelIdxList(varargin_1, numObjs, stats, &statsAlreadyComputed);
  if (!statsAlreadyComputed.Extrema) {
    statsAlreadyComputed.Extrema = true;
    ComputePixelList(stats, &statsAlreadyComputed);
    i = stats.size(0);
    for (k = 0; k < i; k++) {
      idx = stats[k].PixelList.size(0);
      if (stats[k].PixelList.size(0) == 0) {
        for (nblocks = 0; nblocks < 16; nblocks++) {
          stats[k].Extrema[nblocks] = 0.5;
        }
      } else {
        double c1_tmp_tmp;
        double c2_tmp_tmp;
        double d1;
        double d2;
        double d3;
        double maxC;
        double maxR;
        double minC;
        r.set_size(stats[k].PixelList.size(0));
        for (nblocks = 0; nblocks < idx; nblocks++) {
          r[nblocks] = stats[k].PixelList[nblocks + stats[k].PixelList.size(0)];
        }
        idx = stats[k].PixelList.size(0);
        c.set_size(stats[k].PixelList.size(0));
        for (nblocks = 0; nblocks < idx; nblocks++) {
          c[nblocks] = stats[k].PixelList[nblocks];
        }
        minR = internal::minimum(r);
        maxR = internal::maximum(r);
        minC = internal::minimum(c);
        maxC = internal::maximum(c);
        nblocks = stats[k].PixelList.size(0) - 1;
        idx = 0;
        for (lastBlockLength = 0; lastBlockLength <= nblocks;
             lastBlockLength++) {
          if (stats[k].PixelList[lastBlockLength +
                                 stats[k].PixelList.size(0)] == minR) {
            idx++;
          }
        }
        tmp.set_size(idx);
        idx = 0;
        for (lastBlockLength = 0; lastBlockLength <= nblocks;
             lastBlockLength++) {
          if (stats[k].PixelList[lastBlockLength +
                                 stats[k].PixelList.size(0)] == minR) {
            tmp[idx] = stats[k].PixelList[lastBlockLength];
            idx++;
          }
        }
        c1_tmp_tmp = internal::minimum(tmp);
        c2_tmp_tmp = internal::maximum(tmp);
        nblocks = stats[k].PixelList.size(0) - 1;
        idx = 0;
        for (lastBlockLength = 0; lastBlockLength <= nblocks;
             lastBlockLength++) {
          if (stats[k].PixelList[lastBlockLength] == maxC) {
            idx++;
          }
        }
        tmp.set_size(idx);
        idx = 0;
        for (lastBlockLength = 0; lastBlockLength <= nblocks;
             lastBlockLength++) {
          if (stats[k].PixelList[lastBlockLength] == maxC) {
            tmp[idx] =
                stats[k]
                    .PixelList[lastBlockLength + stats[k].PixelList.size(0)];
            idx++;
          }
        }
        d = internal::minimum(tmp);
        d1 = internal::maximum(tmp);
        nblocks = stats[k].PixelList.size(0) - 1;
        idx = 0;
        for (lastBlockLength = 0; lastBlockLength <= nblocks;
             lastBlockLength++) {
          if (stats[k].PixelList[lastBlockLength +
                                 stats[k].PixelList.size(0)] == maxR) {
            idx++;
          }
        }
        tmp.set_size(idx);
        idx = 0;
        for (lastBlockLength = 0; lastBlockLength <= nblocks;
             lastBlockLength++) {
          if (stats[k].PixelList[lastBlockLength +
                                 stats[k].PixelList.size(0)] == maxR) {
            tmp[idx] = stats[k].PixelList[lastBlockLength];
            idx++;
          }
        }
        d2 = internal::maximum(tmp);
        d3 = internal::minimum(tmp);
        nblocks = stats[k].PixelList.size(0) - 1;
        idx = 0;
        for (lastBlockLength = 0; lastBlockLength <= nblocks;
             lastBlockLength++) {
          if (stats[k].PixelList[lastBlockLength] == minC) {
            idx++;
          }
        }
        tmp.set_size(idx);
        idx = 0;
        for (lastBlockLength = 0; lastBlockLength <= nblocks;
             lastBlockLength++) {
          if (stats[k].PixelList[lastBlockLength] == minC) {
            tmp[idx] =
                stats[k]
                    .PixelList[lastBlockLength + stats[k].PixelList.size(0)];
            idx++;
          }
        }
        stats[k].Extrema[0] = c1_tmp_tmp - 0.5;
        stats[k].Extrema[8] = minR - 0.5;
        stats[k].Extrema[1] = c2_tmp_tmp + 0.5;
        stats[k].Extrema[9] = minR - 0.5;
        stats[k].Extrema[2] = maxC + 0.5;
        stats[k].Extrema[10] = d - 0.5;
        stats[k].Extrema[3] = maxC + 0.5;
        stats[k].Extrema[11] = d1 + 0.5;
        stats[k].Extrema[4] = d2 + 0.5;
        stats[k].Extrema[12] = maxR + 0.5;
        stats[k].Extrema[5] = d3 - 0.5;
        stats[k].Extrema[13] = maxR + 0.5;
        stats[k].Extrema[6] = minC - 0.5;
        stats[k].Extrema[14] = internal::maximum(tmp) + 0.5;
        stats[k].Extrema[7] = minC - 0.5;
        stats[k].Extrema[15] = internal::minimum(tmp) - 0.5;
      }
    }
  }
  ComputePixelIdxList(varargin_1, numObjs, stats, &statsAlreadyComputed);
  if (!statsAlreadyComputed.Centroid) {
    statsAlreadyComputed.Centroid = true;
    ComputePixelList(stats, &statsAlreadyComputed);
    i = stats.size(0);
    for (k = 0; k < i; k++) {
      double y[2];
      if (stats[k].PixelList.size(0) == 0) {
        y[0] = 0.0;
        y[1] = 0.0;
      } else {
        if (stats[k].PixelList.size(0) <= 1024) {
          idx = stats[k].PixelList.size(0);
          lastBlockLength = 0;
          nblocks = 1;
        } else {
          idx = 1024;
          nblocks = static_cast<int>(
              static_cast<unsigned int>(stats[k].PixelList.size(0)) >> 10);
          lastBlockLength = stats[k].PixelList.size(0) - (nblocks << 10);
          if (lastBlockLength > 0) {
            nblocks++;
          } else {
            lastBlockLength = 1024;
          }
        }
        for (int xi = 0; xi < 2; xi++) {
          int xpageoffset;
          xpageoffset = xi * stats[k].PixelList.size(0);
          y[xi] = stats[k].PixelList[xpageoffset];
          for (int b_k = 2; b_k <= idx; b_k++) {
            y[xi] += stats[k].PixelList[(xpageoffset + b_k) - 1];
          }
          for (int ib = 2; ib <= nblocks; ib++) {
            int hi;
            int xblockoffset;
            xblockoffset = xpageoffset + ((ib - 1) << 10);
            minR = stats[k].PixelList[xblockoffset];
            if (ib == nblocks) {
              hi = lastBlockLength;
            } else {
              hi = 1024;
            }
            for (int b_k = 2; b_k <= hi; b_k++) {
              minR += stats[k].PixelList[(xblockoffset + b_k) - 1];
            }
            y[xi] += minR;
          }
        }
      }
      stats[k].Centroid[0] =
          y[0] / static_cast<double>(stats[k].PixelList.size(0));
      stats[k].Centroid[1] =
          y[1] / static_cast<double>(stats[k].PixelList.size(0));
    }
  }
  ComputePixelIdxList(varargin_1, numObjs, stats, &statsAlreadyComputed);
  if (!statsAlreadyComputed.Area) {
    i = stats.size(0);
    for (k = 0; k < i; k++) {
      stats[k].Area = stats[k].PixelIdxList.size(0);
    }
  }
  i = stats.size(0);
  for (k = 0; k < i; k++) {
    for (idx = 0; idx < 16; idx++) {
      outstats[k].Extrema[idx] = stats[k].Extrema[idx];
    }
    outstats[k].Centroid[0] = stats[k].Centroid[0];
    outstats[k].Centroid[1] = stats[k].Centroid[1];
    outstats[k].Area = stats[k].Area;
  }
}

} // namespace coder

// End of code generation (regionprops.cpp)
