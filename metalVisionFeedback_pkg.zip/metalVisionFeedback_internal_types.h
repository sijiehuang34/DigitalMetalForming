//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// metalVisionFeedback_internal_types.h
//
// Code generation for function 'metalVisionFeedback'
//

#ifndef METALVISIONFEEDBACK_INTERNAL_TYPES_H
#define METALVISIONFEEDBACK_INTERNAL_TYPES_H

// Include files
#include "metalVisionFeedback_types.h"
#include "rtwtypes.h"

// Type Definitions
struct struct_T {
  double Extrema[16];
  double Centroid[2];
  double Area;
};

#endif
// End of code generation (metalVisionFeedback_internal_types.h)
