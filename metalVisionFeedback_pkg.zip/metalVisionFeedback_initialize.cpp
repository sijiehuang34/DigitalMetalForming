//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// metalVisionFeedback_initialize.cpp
//
// Code generation for function 'metalVisionFeedback_initialize'
//

// Include files
#include "metalVisionFeedback_initialize.h"
#include "metalVisionFeedback_data.h"
#include "rt_nonfinite.h"

// Function Definitions
void metalVisionFeedback_initialize()
{
  rt_InitInfAndNaN();
  isInitialized_metalVisionFeedback = true;
}

// End of code generation (metalVisionFeedback_initialize.cpp)
