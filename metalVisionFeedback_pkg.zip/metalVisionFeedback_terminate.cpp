//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// metalVisionFeedback_terminate.cpp
//
// Code generation for function 'metalVisionFeedback_terminate'
//

// Include files
#include "metalVisionFeedback_terminate.h"
#include "metalVisionFeedback_data.h"
#include "rt_nonfinite.h"

// Function Definitions
void metalVisionFeedback_terminate()
{
  isInitialized_metalVisionFeedback = false;
}

// End of code generation (metalVisionFeedback_terminate.cpp)
