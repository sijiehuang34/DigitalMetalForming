//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// metalVisionFeedback.h
//
// Code generation for function 'metalVisionFeedback'
//

#ifndef METALVISIONFEEDBACK_H
#define METALVISIONFEEDBACK_H

// Include files
#include "metalVisionFeedback_types.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void metalVisionFeedback(const boolean_T bw[388800], const cell_0 *B,
                                const double L[388800]);

#endif
// End of code generation (metalVisionFeedback.h)
